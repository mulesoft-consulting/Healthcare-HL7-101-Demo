Configuring the demo

- install HL7 connector

- configure database connection global elements in global.xml to point to your database

- (optional) customize the patient, visit and lab data in the create-db get:/dbload/create-db-config flow
  	- patient, visit and lab IDs are unique and ascending
  	- every visitId is associated with a patientId
  	- every labId is associated with a visitId
	- only the lab results related to the lost recent (highest) visitId is returned by the API query
  
- run the project
	- there is minimal error checking so choose the happy path 
    	- only query existing patients/visits/labs
    	- always have a visit associated with a patient
    	- always have a lab associated with a visit
    	- patients, labs, and visits can be created via the APIs

  	- patients API - get patients to see the list of patients and their IDs
  		- get/patients and point out paitentId 2 (Jim Williams)
  		- clear the console
  		- get/lastvisit for paitentId 2 and point out admit date, lab results and physician
  		- show the console and point out the QRY_A19 in XML, the HL7 payload and the ADR_A19 XML response
  	
  	- EMR API
  		- get visits and point out visitId 3 is associated with patientId 2 and the physician
  		- get labresults and point out results associated with visitId 3
  		- post labresult for visitId 3 using today's date and the defined formats
  	
  	- patient API - get patients to see the list of patients and their IDs
  		- get lastvisit for paitentId 2 and point out the new result
  		
- reset the database with the create-db API

Demo Script

A new patient sees a doctor. The admissions clerk looks up existing patients, and creates a new patient 
record for the patient using the POST method in the patient API. A unique patient ID is generated.

The patient is referred to a lab to have their annual blood test done. The admissions clerk at the lab 
creates a new visit record for the patient using the new patient ID. A unique visit record is generated.

After the results come back from the test the clerk makes a new entry into the LSI for the lab results, 
using the unique visit ID.

The patient returns to their doctor and their lab results are requested from the LSI using an QRY_A19. 
The ADR_A19 response comes back with their results. 

In the logs you show the QRY_A19 as XML and EDI that is sent, and the ADR_A19 that is returned.
